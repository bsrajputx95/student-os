export function reserveStock(stock, cart) {
  for (const item of cart) {
    if (stock[item.sku] < item.qty) return {ok:false,stock};
    stock[item.sku] -= item.qty;
  }
  return {ok:true,stock};
}
