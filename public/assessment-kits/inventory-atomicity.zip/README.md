# The checkout oversells inventory

Original StudentOS practice project. No real payments or external services.

## Incident
A cart can contain the same SKU twice. Stock is decremented line by line, and failed checkouts leave partially modified inventory.

## Your task
reserveStock(stock, cart) returns {ok:true,stock:updatedStock} if every requested quantity can be reserved, or {ok:false,stock:originalStock} otherwise. Aggregate repeated SKUs. Quantities must be positive integers and every SKU must exist. Never mutate the input stock or cart.

- Duplicate cart lines are aggregated.
- The whole reservation succeeds or nothing changes.
- Unknown SKUs and invalid quantities fail.

## Run
Node 22+; no dependency installation required.

    npm test

Edit src/inventory.js, rerun tests, and explain your fix and one regression risk. Starter tests intentionally fail. Tests are supplied for local practice, not a proctored hiring assessment.
