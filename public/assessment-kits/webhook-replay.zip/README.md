# The customer was charged twice

Original StudentOS practice project. No real payments or external services.

## Incident
A payment provider retries a webhook after a timeout. The ledger credits the same payment twice, and pending events also change the balance.

## Your task
Return a new ledger with balanceCents and seen. Only a payment.succeeded event with a positive integer amountCents may credit the balance. Ignore an event already in seen. Do not mutate the supplied ledger. Only successfully processed IDs join seen.

- A successful payment credits integer cents once.
- Replayed, pending, negative, and fractional amounts leave the ledger unchanged.
- Input objects remain unchanged.

## Run
Node 22+; no dependency installation required.

    npm test

Edit src/webhooks.js, rerun tests, and explain your fix and one regression risk. Starter tests intentionally fail. Tests are supplied for local practice, not a proctored hiring assessment.
