export function handleWebhook(ledger, event) {
  return { balanceCents: ledger.balanceCents + event.amountCents, seen: [...ledger.seen, event.id] };
}
