# A retry storm takes down checkout

Original StudentOS practice project. No real payments or external services.

## Incident
The client retries every unsuccessful response immediately. A short provider outage becomes a flood of repeated requests.

## Your task
Return {retry,delayMs}. Retry only HTTP 429 and 500–599 while attempt is 0, 1, or 2. Use 1000 * 2^attempt milliseconds, except a positive Retry-After value on 429 takes precedence (seconds converted to milliseconds). For all other cases return {retry:false,delayMs:0}.

- Permanent client errors do not retry.
- Attempts are bounded.
- Rate limits respect Retry-After.

## Run
Node 22+; no dependency installation required.

    npm test

Edit src/retry.js, rerun tests, and explain your fix and one regression risk. Starter tests intentionally fail. Tests are supplied for local practice, not a proctored hiring assessment.
