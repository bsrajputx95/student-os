import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {retryPlan} from '../src/retry.js';
const cases=JSON.parse(readFileSync(new URL('../fixtures/cases.json',import.meta.url),'utf8'));
for(const item of cases)test(item.name,async()=>{const args=structuredClone(item.args),before=structuredClone(args);assert.deepEqual(await retryPlan(...args),item.expected);assert.deepEqual(args,before,'Do not mutate inputs');});
