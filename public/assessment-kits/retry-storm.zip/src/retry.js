export function retryPlan(status, attempt, retryAfterSeconds) {
  return {retry:status !== 200,delayMs:0};
}
