# An API leaks another tenant’s orders

Original StudentOS practice project. No real payments or external services.

## Incident
Pagination is applied before tenant filtering. Responses skip valid orders and sometimes include another tenant’s records.

## Your task
listOrders(orders, tenantId, cursor, limit) returns only that tenant’s orders whose numeric id is greater than cursor, sorted by id ascending, then limited. A limit below 1 returns an empty array. Do not mutate orders.

- Tenant isolation is enforced before slicing.
- Cursor ordering is deterministic.
- Input arrays are preserved.

## Run
Node 22+; no dependency installation required.

    npm test

Edit src/orders.js, rerun tests, and explain your fix and one regression risk. Starter tests intentionally fail. Tests are supplied for local practice, not a proctored hiring assessment.
