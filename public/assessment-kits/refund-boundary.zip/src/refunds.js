export function refundPayment(payment, amountCents) {
  if (amountCents > payment.capturedCents) return {ok:false,error:"EXCEEDS_CAPTURED"};
  return {ok:true,totalRefundedCents:payment.refundedCents / 100 + amountCents};
}
