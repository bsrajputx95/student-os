# Refunds exceed the captured amount

Original StudentOS practice project. No real payments or external services.

## Incident
Partial refunds are processed in mixed units. Repeated requests can refund more money than was captured.

## Your task
refundPayment(payment, amountCents) returns {ok:true,totalRefundedCents} for valid refunds. All money uses integer cents. Return {ok:false,error} with NOT_CAPTURED for any status other than captured; INVALID_REFUND for non-positive or fractional amounts; EXCEEDS_CAPTURED if cumulative refunds exceed capturedCents. Check in that order. Do not mutate payment.

- Integer minor units throughout.
- Existing refunds count toward the limit.
- A refund equal to the remaining captured amount succeeds.

## Run
Node 22+; no dependency installation required.

    npm test

Edit src/refunds.js, rerun tests, and explain your fix and one regression risk. Starter tests intentionally fail. Tests are supplied for local practice, not a proctored hiring assessment.
